const { interval, range, timer } = Rx;
const { take, delay } = RxOperators;

//interval(1000).pipe(
//  take(4)
//)

//range(1,4)

//timer(0, 1000)